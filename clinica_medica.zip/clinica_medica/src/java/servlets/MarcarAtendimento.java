package servlets;

import banco_dados.ConexaoBancoDados;
import banco_dados.ProntuarioDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.Prontuario;

/**
 *
 * @author Danilo
 */
public class MarcarAtendimento extends HttpServlet {
    public MarcarAtendimento() {
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        String strHistorico = "";
        String strReceituario = "";
        String strExames = "";
        int intRegistroAgenda = Integer.parseInt(request
                .getParameter("registro_agenda"));
        int intCodigoPaciente = Integer.parseInt(request
                .getParameter("codigo_paciente"));
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE hmtl>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Atendimento de Consulta "
                + "Médica</p>");
        
        try
        {
            if (request.getParameter("txtHistorico").length() > 0) {
                strHistorico = request.getParameter("txtHistorico");
            }
            
            if (request.getParameter("txtReceituario").length() > 0) {
                strReceituario = request.getParameter("txtReceituario");
            }
            
            if (request.getParameter("txtExames").length() > 0) {
                strExames = request.getParameter("txtExames");
            }
            
            Prontuario Prontuario = new Prontuario(intRegistroAgenda, 
                    strHistorico, strReceituario, strExames, intCodigoPaciente);
            ConexaoBancoDados Conexao = new ConexaoBancoDados();
            ProntuarioDao Prontuarios = new ProntuarioDao();
            if (Conexao.abrirConexao()) {
                Prontuarios.configurarConexao(Conexao.obterConexao());
                if (Prontuarios.registrarAtendimento(Prontuario)) {
                    out.println("<h2>Atendimento de consulta registrado "
                            + "com sucesso!</h2>");
                    out.println("<br><br><br><br>");
                    out.println("<a href='atender_consulta.jsp'>Voltar</a>");
                } else {
                    out.println("<h2>Não foi possível registrar o "
                            + "atendimento!</h2>");
                }
                
                Conexao.fecharConexao();
            } else {
                out.println("<h2>Não foi possível estabelecer conexão "
                        + "com o banco de dados!</h2>");
            }
        } catch (Exception erro) {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de atendimento "
                    + "de consulta!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
