/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import banco_dados.ConexaoBancoDados;
import banco_dados.EspecialidadeDao;

/**
 *
 * @author Danilo
 */
public class InserirEspecialidade extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        String strDescricao;
        PrintWriter out;
        
        strDescricao = request.getParameter("txtDescricao");
        
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8'/>");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css'/>");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Cadastro de Especialidade "
                + "Médicas</p>");
        
        try
        {
            ConexaoBancoDados conexao = new ConexaoBancoDados();
            EspecialidadeDao especialidade = new EspecialidadeDao();
            
            if (conexao.abrirConexao())
            {
                especialidade.configurarConexao(conexao.obterConexao());
                
                if (especialidade.inserirRegistro(strDescricao))
                {
                    out.println("<h2>Especialidade cadastrada com sucesso!"
                            + "</h2>");
                    out.println("<br><br><br><br>");
                    out.println("<a href='menu_especialidades.html'>"
                            + "Voltar</a>");
                }
                else
                    out.println("<h2>Não foi possível cadastrar a "
                            + "especialidade!</h2>");
                
                conexao.fecharConexao();
            }
            else
                out.println("<h2>Não foi possível estabelecer conexão com "
                        + "o banco de dados!</h2>");
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de cadastro de "
                    + "especialidade médica!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
