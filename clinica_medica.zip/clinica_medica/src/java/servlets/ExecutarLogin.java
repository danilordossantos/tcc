/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import banco_dados.ConexaoBancoDados;
import banco_dados.UsuarioDao;
import java.sql.ResultSet;

/**
 *
 * @author Danilo
 */
public class ExecutarLogin extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        ResultSet rsRegistro;
        PrintWriter out;
        String strUsuario = request.getParameter("txtUsuario");
        String strSenha = request.getParameter("txtSenha").trim().toUpperCase();
        String strPagina = request.getParameter("pagina");
        int intCodigoUsuario;
        
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        //HttpSession sessao = request.getSession();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Login do Sistema</p>");
        
        try
        {
            ConexaoBancoDados conexao = new ConexaoBancoDados();
            UsuarioDao usuario = new UsuarioDao();
            
            if (conexao.abrirConexao())
            {
                usuario.configurarConexao(conexao.obterConexao());
                
                intCodigoUsuario = usuario.localizarRegistro(strUsuario);
                
                /*if (strUsuario.equals("jsp")) {
                    sessao.setAttribute("usuario_logado", true);
                    sessao.setAttribute("nome_usuario", strUsuario);
                    out.println("<h2>Bem-vindo, "+strUsuario+"</h2>");
                    out.println("<br><br>");
                    out.println("<a href='menu_administracao.html'>Módulo Administrativo</a>");
                } else {
                    out.println("<p>Usuário ou senha inválidos</p>");
                    out.println("<a href='login.jsp'>Tentar novamente.</a>");
                }*/
                
                if (intCodigoUsuario != 0)
                {
                    rsRegistro = usuario.lerRegistro(intCodigoUsuario);
                    
                    if (rsRegistro.getString("Senha_Acesso").trim()
                            .equals(strSenha))
                        
                    {
                        response.sendRedirect(strPagina);
                    }
                    else
                    {
                        out.println("<h2>Senha inválida!</h2>");
                        out.println("<br><br><br>");
                        out.println("<p class='LinkVoltar'>"
                                + "<a href='javascript:history.back()'>"
                                + "[Voltar]</a></p>");
                    }
                }
                else
                {
                    out.println("<h2>Usuário não encontrado!</h2>");
                    out.println("<br><br><br>");
                    out.println("<p class='LinkVoltar'>"
                            + "<a href='javascript:history.back()'>"
                            + "[Voltar]</a></p>");
                }
                conexao.fecharConexao();
            }
            else
                out.println("<h2>Não foi possível estabelecer conexão "
                        + "com o banco de dados!</h2>");
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de login!</h2>");
        }
        
        out.println("</body>");
        out.println("</html>");
    }
}
