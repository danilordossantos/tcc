/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import banco_dados.ConexaoBancoDados;
import banco_dados.PacienteDao;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.*;

/**
 *
 * @author Danilo
 */
public class PesquisarPaciente extends HttpServlet {
    public PesquisarPaciente() {
    }
    
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, 
            HttpServletResponse response)
            throws ServletException, IOException {
        boolean blnProcessa = true;
        Conversao Converter = new Conversao();
        Validacao Validar = new Validacao();
        ConexaoBancoDados Conexao = new ConexaoBancoDados();
        PacienteDao Paciente = new PacienteDao();
        String strOpcaoPesquisa = request.getParameter("rbOpcaoPesquisa");
        String strNome = request.getParameter("txtNomePaciente");
        String strRG = request.getParameter("txtRG");
        String strCPF = request.getParameter("txtCPF");
        String strCampoPesquisa = "";
        String strValorPesquisa = "";
        if (strOpcaoPesquisa.equals("RG")) {
            strCampoPesquisa = "RG";
            strValorPesquisa = strRG;
        } else if (strOpcaoPesquisa.equals("CPF")) {
            strCampoPesquisa = "CPF";
            strValorPesquisa = strCPF;
            if (!Validar.CPFValido(strCPF)) {
                blnProcessa = false;
            }
        }
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Cadastro de Pacientes</p>");
        ResultSet rsRegistro;
        if (strOpcaoPesquisa.equals("Nome")) {
            try {
                if (Conexao.abrirConexao()) {
                    Paciente.configurarConexao(Conexao.obterConexao());
                    rsRegistro = Paciente.listarRegistros(strNome);
                    if (rsRegistro == null) {
                        out.println("<p>Falha na exibição dos registros!</p>");
                    } else {
                        out.println("<h2><center>Lista de pacientes</center>"
                                + "</h2>");
                        out.println("<br>");
                        out.println("<table align='center' "
                                + "bgcolor='moccasin'>");
                        out.println("<tr><th>Nome do paciente</th>"
                                + "<th>Número do RG</th><th>Número do CPF</th>"
                                + "<th></th></tr>");
                        
                        while(rsRegistro.next()) {
                            out.print("<tr>");
                            out.print("<td>" + rsRegistro.getString("Nome") 
                                    + "</td>");
                            out.print("<td>" + rsRegistro.getString("Numero_RG") 
                                    + "</td>");
                            out.print("<td>" + rsRegistro
                                    .getString("Numero_CPF") + "</td>");
                            out.print("<td><a href='editar_paciente."
                                    + "jsp?codigo_paciente=" + rsRegistro
                                            .getString("Codigo_Paciente") 
                                    + "'>Editar</a></td>");
                            out.print("</tr>");
                        }
                        
                        out.println("</table>");
                        out.println("<br>");
                    }
                    
                    Conexao.fecharConexao();
                } else {
                    out.println("<p>Falha na conexão com o banco de dados!"
                            + "</p>");
                }
            } catch (SQLException erro) {
                System.out.println(erro.getMessage());
                out.println("<h2>Erro do sistema: processo de cadastro "
                        + "de paciente!</h2>");
            }
        } else if (blnProcessa) {
            try {
                if (Conexao.abrirConexao()) {
                    Paciente.configurarConexao(Conexao.obterConexao());
                    int intCodigoPaciente = Paciente.
                            localizarRegistro(strCampoPesquisa, 
                                    strValorPesquisa);
                    if (intCodigoPaciente != 0) {
                        rsRegistro = Paciente.lerRegistro(intCodigoPaciente);
                        String strDataNascimento = Converter.
                                DateToString(rsRegistro
                                        .getDate("Data_Nascimento"));
                        out.println("Nome do paciente: " + 
                                rsRegistro.getString("Nome") + "<br>");
                        out.println("Data de nascimento: " + strDataNascimento 
                                + " - Sexo: " + rsRegistro.getString("Sexo") 
                                + "<br>");
                        out.println("RG: " + rsRegistro.getString("Numero_RG") 
                                + " - Órgão Emissor: " + rsRegistro
                                .getString("Orgao_Emissor") + "<br>");
                        out.println("CPF: " + rsRegistro.getString("Numero_CPF") 
                                + "<br>");
                        out.println("Endereço: " + rsRegistro
                                .getString("Endereco") + "," + rsRegistro
                                        .getString("Numero") + "<br>");
                        out.println("Complemento: " + rsRegistro
                                .getString("Complemento") + "<br>");
                        out.println("Cidade: " + rsRegistro.getString("Cidade") 
                                + " - Estado: " + rsRegistro.getString("Estado") 
                                + "<br>");
                        out.println("Telefone: " + rsRegistro
                                .getString("Telefone") + " - Celular: " 
                                + rsRegistro
                                .getString("Celular") + "<br>");
                        out.println("<br><br>");
                        out.println("<a href='editar_paciente.jsp?"
                                + "codigo_paciente=" + intCodigoPaciente 
                                + "'>[Editar]</a> ");
                        out.println("<span class='LinkVoltar'>"
                                + "<a href='javascript:history.back()'>[Voltar]"
                                + "</a></span>");
                    } else {
                        out.println("<h2>Paciente não encontrado!</h2>");
                        out.println("<br><br><br>");
                        out.println("<p class='LinkVoltar'>"
                                + "<a href='javascript:history.back()'>[Voltar]"
                                + "</a></p>");
                    }
                    
                    Conexao.fecharConexao();
                } else {
                    out.println("<h2>Não foi possível estabelecer conexão com "
                            + "o banco de dados!</h2>");
                }
            } catch (SQLException erro) {
                System.out.println(erro.getMessage());
                out.println("<h2>Erro do sistema: processo de cadastro "
                        + "de paciente!</h2>");
            }
        } else {
            response.sendRedirect("mensagem_alerta.jsp?"
                    + "texto_mensagem='CPF com erro!'");
        }
        out.println("</body>");
        out.println("</hmtl>");
    }
}
