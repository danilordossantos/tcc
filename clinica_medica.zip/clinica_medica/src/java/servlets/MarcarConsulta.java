package servlets;

import banco_dados.AgendaConsultaDao;
import banco_dados.ConexaoBancoDados;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.AgendaConsulta;

/**
 *
 * @author Danilo
 */
public class MarcarConsulta extends HttpServlet {
    public MarcarConsulta() {
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Agendamento de "
                + "Consulta Médica</p>");
        
        try {
            String strDataConsulta = request.getParameter("txtDia") + "/" + 
                    request.getParameter("txtMes") + "/" + request
                            .getParameter("txtAno");
            String strHoraConsulta = request.getParameter("txtHora") + ":" + 
                    request.getParameter("txtMinutos");
            AgendaConsulta Agenda = new AgendaConsulta(Integer.parseInt(request
                    .getParameter("codigo_paciente")), Integer.parseInt(request
                            .getParameter("lstMedico")), strDataConsulta, 
                    strHoraConsulta, "N", "N", "", Integer.parseInt(request
                            .getParameter("lstUsuario")));
            ConexaoBancoDados Conexao = new ConexaoBancoDados();
            AgendaConsultaDao Agendas = new AgendaConsultaDao();
            if (Conexao.abrirConexao()) {
                Agendas.configurarConexao(Conexao.obterConexao());
                if (Agendas.inserirRegistro(Agenda)) {
                    out.println("<h2>Consulta agendada com sucesso!</h2>");
                    out.println("<br><br><br><br>");
                    out.println("<a href='menu_agendamento.html'>Voltar</a>");
                } else {
                    out.println("<h2>Não foi possível agendar a consulta!"
                            + "</h2>");
                }
                
                Conexao.fecharConexao();
            } else {
                out.println("<h2>Não foi possível estabelecer conexão com "
                        + "o banco de dados!</h2>");
            }
        } catch (Exception erro) {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de agendamento "
                    + "de consulta!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
