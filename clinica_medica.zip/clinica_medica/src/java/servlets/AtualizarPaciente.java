/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.Paciente;
import banco_dados.ConexaoBancoDados;
import banco_dados.PacienteDao;
import util.*;

/**
 *
 * @author Danilo
 */
public class AtualizarPaciente extends HttpServlet {
    public AtualizarPaciente() {
    }
    
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        PrintWriter out;
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        Validacao Validar = new Validacao();
        Conversao Converter = new Conversao();
        boolean blnProcessar;
        String strTemConvenio = "N";
        String strCPF,strComplemento;
        int intCodigoConvenio = 0;
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Cadastro de Pacientes</p>");
        
        try {
            blnProcessar = true;
            
            // Se tem convênio
            if (request.getParameter("chkTemConvenio") != null && request.getParameter("chkTemConvenio").equals("S")) {
                strTemConvenio = "S";
                intCodigoConvenio = Integer.parseInt(request.getParameter("lstConvenio"));
            }
            
            // Se tem complemento de endereço
            if (!request.getParameter("txtComplemento").trim().toUpperCase()
                    .equals("NULL") && request.getParameter("txtComplemento")
                            .trim().length() != 0) {
                strComplemento = request.getParameter("txtComplemento").trim();
            } else {
                strComplemento = "";
            }
            
            Paciente Paciente = new Paciente(request
                    .getParameter("txtNomePaciente"), request
                            .getParameter("txtRG"), request
                                    .getParameter("txtOrgaoEmissor"), request
                                            .getParameter("txtCPF"), request
                                                    .getParameter("txtEndereco")
                    , request.getParameter("txtNumero"), strComplemento, 
                    request.getParameter("txtBairro"), request
                            .getParameter("txtCidade"), request
                                    .getParameter("lstEstado"), request
                                            .getParameter("txtTelefone"), 
                    request.getParameter("txtCelular"), String.valueOf(request
                            .getParameter("rbSexo").charAt(0)), request
                                    .getParameter("txtDiaNascimento"), request
                                            .getParameter("txtMesNascimento"), 
                    request.getParameter("txtAnoNascimento"), strTemConvenio, 
                    intCodigoConvenio);
            
            Paciente.setCodigoPaciente(Integer.parseInt(request.getParameter("codigo_paciente")));
            
            // Separa somente os dígitos do CPF e verifica se ele é válido, 
            // no caso de ter sido informado
            strCPF = Converter.SoDigito(request.getParameter("txtCPF"));
            
            if (!strCPF.trim().equals("") && !Validar.CPFValido(request
                    .getParameter("txtCPF"))) {
                response.sendRedirect("mensagem_alerta.jsp?texto_mensagem='CPF "
                        + "com erro!'");
                blnProcessar = false;
            }
            
            if (blnProcessar) {
                ConexaoBancoDados conexao = new ConexaoBancoDados();
                PacienteDao paciente = new PacienteDao();
                
                if (conexao.abrirConexao()) {
                    paciente.configurarConexao(conexao.obterConexao());
                    
                    if (paciente.alterarRegistro(Paciente)) {
                        out.println("<h2>Dados do paciente atualizados com "
                                + "sucesso!</h2>");
                        out.println("<br><br><br><br>");
                        out.println("<a href='menu_pacientes.html'>Fechar</a>");
                    } else {
                        out.println("<h2>Não foi possível atualizar os dados "
                                + "do paciente!</h2>");
                    }
                    
                    conexao.fecharConexao();
                } else {
                    out.println("<h2>Não foi possível estabelecer conexão "
                            + "com o banco de dados!</h2>");
                }
            }
        } catch (Exception erro) {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de cadastro de "
                    + "paciente!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
