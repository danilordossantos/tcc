/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.Medico;
import banco_dados.ConexaoBancoDados;
import banco_dados.MedicoDao;

/**
 *
 * @author Danilo
 */
public class InserirMedico extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response)
            throws ServletException, IOException {
        PrintWriter out;
        response.setContentType("text/html;charset=UTF-8");
        out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8'/>");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css'/>");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Cadastro de Médicos</p>");
        
        try
        {
            ConexaoBancoDados conexao = new ConexaoBancoDados();
            MedicoDao medico = new MedicoDao();
            Medico Medico = new Medico(request.getParameter("txtNomeMedico"),
                    request.getParameter("txtCRM"),
                    Integer.parseInt(request.getParameter("lstEspecialidade")),
                    Integer.parseInt(request.getParameter("lstUsuario")));
            
            if (conexao.abrirConexao())
            {
                medico.configurarConexao(conexao.obterConexao());
                
                if (medico.inserirRegistro(Medico))
                {
                    out.println("<h2>Médico cadastrado com sucesso!</h2>");
                    out.println("<br><br><br><br>");
                    out.println("<a href='menu_medicos.html'>Voltar</a>");
                }
                else
                    out.println("<h2>Não foi possível cadastrar o médico!"
                            + "</h2>");
                
                conexao.fecharConexao();
            }
            else
                out.println("<h2>Não foi possível estabelecer conexão com "
                        + "o banco de dados!</h2>");
        }
        catch(Exception erro)
        {
            erro.printStackTrace();
            out.println("<h2>Erro do sistema: processo de cadastro de "
                    + "médico!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}
