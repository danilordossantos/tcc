/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package servlets;

import banco_dados.ConexaoBancoDados;
import banco_dados.PacienteDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import model.Paciente;
import util.*;

/**
 *
 * @author Danilo
 */

public class InserirPaciente extends HttpServlet {
    public InserirPaciente() {
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse 
            response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Validacao Validar = new Validacao();
        Conversao Converter = new Conversao();
        String strTemConvenio = "N";
        int intCodigoConvenio = 0;
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta http-equiv='Content-Type' content='text/html; "
                + "charset=utf-8' />");
        out.println("<title>MedAcad</title>");
        out.println("<link href='clinica_medica.css' rel='stylesheet' "
                + "type='text/css' />");
        out.println("</head>");
        out.println("<body class='FundoPagina'>");
        out.println("<p class='TituloAplicacao'>MedAcad</p>");
        out.println("<p class='TituloPagina'>Cadastro de Pacientes</p>");

        try {
            boolean blnProcessar = true;
            String convenio = request.getParameter("convenio");
            if (convenio.equals("S")) {
                strTemConvenio = "S";
                intCodigoConvenio = Integer.parseInt(request
                        .getParameter("lstConvenio"));
            }

            Paciente Paciente = new Paciente(request
                    .getParameter("txtNomePaciente"), request
                            .getParameter("txtRG"), 
                    request.getParameter("txtOrgaoEmissor"), request
                            .getParameter("txtCPF"), request
                                    .getParameter("txtEndereco"), 
                    request.getParameter("txtNumero"), request
                            .getParameter("txtComplemento"), request
                                    .getParameter("txtBairro"), 
                    request.getParameter("txtCidade"), request
                            .getParameter("lstEstado"), request
                                    .getParameter("txtTelefone"), 
                    request.getParameter("txtCelular"), String
                            .valueOf(request.getParameter("rbSexo").charAt(0)), 
                    request.getParameter("txtDiaNascimento"), request
                            .getParameter("txtMesNascimento"), 
                    request.getParameter("txtAnoNascimento"), strTemConvenio, 
                    intCodigoConvenio);
            
            String strCPF = Converter.SoDigito(request.getParameter("txtCPF"));
            String strSenha;
            if (strCPF.trim().equals("")) {
                strSenha = "123456";
            } else {
                strSenha = strCPF.substring(0, 6);
            }

            Paciente.setSenhaAcesso(strSenha);
            if (!strCPF.trim().equals("") && !Validar.CPFValido(request
                    .getParameter("txtCPF"))) {
                response.sendRedirect("mensagem_alerta.jsp?texto_mensagem"
                        + "='CPF com erro!'");
                blnProcessar = false;
            }

            if (blnProcessar) {
                ConexaoBancoDados Conexao = new ConexaoBancoDados();
                PacienteDao Pacientes = new PacienteDao();
                if (Conexao.abrirConexao()) {
                    Pacientes.configurarConexao(Conexao.obterConexao());
                    if (Pacientes.inserirRegistro(Paciente)) {
                        out.println("<h2>Paciente cadastrado com sucesso!"
                                + "</h2>");
                        out.println("<br><br><br><br>");
                        out.println("<a href='menu_pacientes.html'>Voltar</a>");
                    } else {
                        out.println("<h2>Não foi possível cadastrar o paciente!"
                                + "</h2>");
                    }

                    Conexao.fecharConexao();
                } else {
                    out.println("<h2>Não foi possível estabelecer conexão com "
                            + "o banco de dados!</h2>");
                }
            }
        } catch (IOException | NumberFormatException erro) {
            out.println("<h2>Erro do sistema: processo de cadastro de "
                    + "paciente!</h2>");
        }
        out.println("</body>");
        out.println("</html>");
    }
}

