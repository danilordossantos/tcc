/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.*;
import model.UsuarioVinculo;

/**
 *
 * @author Danilo
 */
public class UsuarioVinculoDao { /* Vínculo de usuários */ 
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public boolean inserirRegistro(UsuarioVinculo vincula)
    {
        String strComandoSQL;
        
        try 
        {
            strComandoSQL = "INSERT into vincula_usuario(Codigo_Funcionario,Registro_Usuario)"+
                    " VALUES("+vincula.getCodigoFuncionario()+","+
                    vincula.getCodigoUsuario()+")";
        
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
        
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet lerRegistro(int intCodigoUsuarioVinculo)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM vincula_usuario WHERE Codigo_Vinculo = "+intCodigoUsuarioVinculo;
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();
            
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarRegistro(UsuarioVinculo vincula)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "UPDATE vincula_usuario SET Codigo_Funcionario = "+vincula.getCodigoFuncionario()+","+
                    "Registro_Usuario = "+vincula.getCodigoUsuario()+
                    " WHERE Codigo_Vinculo = "+vincula.getCodigoUsuarioVinculo();
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int intCodigoUsuarioVinculo)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "DELETE FROM vincula_usuario WHERE Codigo_Vinculo = "+intCodigoUsuarioVinculo;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet listarRegistro() 
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT vincula_usuario.Codigo_Vinculo AS CodigoUsuarioVinculo,"+
                    "vincula_usuario.Codigo_Funcionario AS CdFuncionario," +
                    "vincula_usuario.Registro_Usuario AS CdUsuario," +
                    "funcionarios.Codigo_Funcionario AS CodigoFuncionario," +
                    "funcionarios.Nome_Completo AS NomeFuncionario," +
                    "usuarios.Registro_Usuario AS CodigoUsuario," +
                    "usuarios.Identificacao_Usuario AS IdUsuario" +
                    " FROM vincula_usuario,funcionarios,usuarios" +
                    " WHERE (vincula_usuario.Codigo_Funcionario = funcionarios.Codigo_Funcionario) AND" +
                    " (vincula_usuario.Registro_Usuario = usuarios.Registro_Usuario) " +
                    " ORDER BY usuarios.Identificacao_Usuario";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
}
