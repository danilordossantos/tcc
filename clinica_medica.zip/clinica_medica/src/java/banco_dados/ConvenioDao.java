/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.*;
import model.Convenio;

/**
 *
 * @author Danilo
 */
public class ConvenioDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = 
            conBanco;}
    
    public boolean inserirRegistro(Convenio convenio)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "INSERT INTO convenios(Empresa_Convenio,CNPJ,"
                    + "Telefone)"+
                    " VALUES('"+convenio.getNomeConvenio()+"',"+
                    "'"+convenio.getCNPJ()+"',"+
                    "'"+convenio.getTelefone()+"')";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet lerRegistro(int intCodigoConvenio)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM convenios WHERE Codigo_Convenio = "
                    +intCodigoConvenio;
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();
            
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarRegistro(Convenio convenio)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "UPDATE convenios SET Empresa_Convenio = '"
                    +convenio.getNomeConvenio()+"',"+
                    "CNPJ = '"+convenio.getCNPJ()+"',"+
                    "Telefone = '"+convenio.getTelefone()+"'"+
                    " WHERE Codigo_Convenio = "+convenio.getCodigoConvenio();
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int intCodigoConvenio)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "DELETE FROM convenios WHERE Codigo_Convenio = "
                    +intCodigoConvenio;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet listarRegistros()
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM convenios ORDER BY Empresa_Convenio";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
}
