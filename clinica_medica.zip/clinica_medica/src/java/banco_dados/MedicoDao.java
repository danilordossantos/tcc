/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.*;
import model.Medico;
/**
 *
 * @author Danilo
 */
public class MedicoDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = 
            conBanco;}
    
    public boolean inserirRegistro(Medico medico)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "INSERT INTO medicos(Nome_Medico,CRM,"
                    + "Codigo_Especialidade,Codigo_Usuario)"+
                    " VALUES('"+medico.getNomeMedico()+"',"+
                    "'"+medico.getCRM()+"',"+
                    medico.getCodigoEspecialidade()+","+
                    medico.getCodigoUsuario()+")";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet lerRegistro(int intCodigoMedico)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM medicos WHERE Codigo_Medico = "
                    +intCodigoMedico;
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();
            
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarRegistro(Medico medico)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "UPDATE medicos SET Nome_Medico = '"+medico
                    .getNomeMedico()+"',"+
                    "CRM = '"+medico.getCRM()+"',"+
                    "Codigo_Especialidade = "+medico
                            .getCodigoEspecialidade()+","+
                    "Codigo_Usuario = "+medico.getCodigoUsuario()+
                    " WHERE Codigo_Medico = "+medico.getCodigoMedico();
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int intCodigoMedico)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "DELETE FROM medicos WHERE Codigo_Medico = "
                    +intCodigoMedico;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet listarRegistros()
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM medicos ORDER BY Nome_Medico";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
    
    public ResultSet listarMedicosEspecialidades()
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT medicos.Codigo_Medico AS CodigoMedico,"+
                    "medicos.Nome_Medico AS Medico,"+
                    "medicos.Codigo_Especialidade AS MedicoEspecialidade,"+
                    "medicos.Codigo_Usuario AS CodigoUsuario,"+
                    "especialidades.Codigo_Especialidade "
                    + "AS CodigoEspecialidade,"+
                    "especialidades.Descricao_Especialidade AS Especialidade"+
                    " FROM medicos,especialidades"+
                    " WHERE medicos.Codigo_Especialidade = especialidades"
                    + ".Codigo_Especialidade ORDER BY medicos.Nome_Medico";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
}
