/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.*;

/**
 *
 * @author Danilo
 */
public class EspecialidadeDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public void configurarConexao(Connection conBanco) {this.conBanco = 
            conBanco;}
    
    public boolean inserirRegistro(String strDescricao) 
    {
        String strComandoSQL;
        
        try {
            strComandoSQL = "INSERT INTO especialidades(Descricao_"
                    + "Especialidade) VALUES('"+strDescricao+"')";
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet lerRegistro(int intCodigoEspecialidade)
    {
        String strComandoSQL;
        
        try
        {
            strComandoSQL = "SELECT * FROM especialidades WHERE "
                    + "Codigo_Especialidade = "+intCodigoEspecialidade;
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            rsRegistros.next();
            
            return rsRegistros;
        }
        catch (Exception erro)
        {
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarRegistro(int intCodigo,String strDescricao) {
        String strComandoSQL;
        
        try {
            strComandoSQL = "UPDATE especialidades SET Descricao_Especialidade "
                    + "= '"+strDescricao+"' WHERE Codigo_Especialidade = "
                    +intCodigo;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean excluirRegistro(int intCodigo) {
        String strComandoSQL;
        
        try {
            strComandoSQL = "DELETE FROM especialidades WHERE Codigo_"
                    + "Especialidade = "+intCodigo;
            psComando = conBanco.prepareStatement(strComandoSQL);
            psComando.executeUpdate();
            
            return true;
        }
        catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet listarRegistros(String strOrdem) {
        String strComandoSQL;
        
        try {
            if (strOrdem == "CÓDIGO")
                strComandoSQL = "SELECT * FROM especialidades ORDER BY "
                        + "Codigo_Especialidade";
            else
                strComandoSQL = "SELECT * FROM especialidades ORDER BY "
                        + "Descricao_Especialidade";
            
            psComando = conBanco.prepareStatement(strComandoSQL);
            rsRegistros = psComando.executeQuery();
            return rsRegistros;
        }
        catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
}
