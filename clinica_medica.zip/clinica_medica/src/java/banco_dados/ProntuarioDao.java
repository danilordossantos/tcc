package banco_dados;

import java.sql.*;
import java.util.Date;
import model.Prontuario;
import util.Conversao;
/**
 *
 * @author Danilo
 */
public class ProntuarioDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public ProntuarioDao() {
    }
    
    public void configurarConexao(Connection conBanco) { this.conBanco = conBanco; }
    
    public boolean registrarAtendimento(Prontuario prontuario) {
        try {
            String strComandoSQL = "INSERT INTO prontuario_paciente(Registro"
                    + "_Agenda,Historico,Receituario,Exames,Codigo_Paciente) "
                    + "VALUES(" + prontuario.getRegistroAgenda() + "," + "'" + 
                    prontuario.getHistorico() + "'," + "'" + prontuario
                            .getReceituario() + "'," + "'" + prontuario
                                    .getExames() + "'," + prontuario
                                            .getCodigoPaciente() + ")";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            
            strComandoSQL = "UPDATE agenda_consulta SET Atendido = 'S' WHERE "
                    + "Registro_Agenda = " + prontuario.getRegistroAgenda();
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            
            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet listarAgenda() {
        Conversao Converter = new Conversao();
        Date dtData = new Date(System.currentTimeMillis());
        String strData = Converter.DataInvertida(dtData);
        
        try {
            String strComandoSQL = "SELECT agenda_consulta.Registro_Agenda AS "
                    + "RegistroAgenda,agenda_consulta.Codigo_Paciente AS "
                    + "CodigoPaciente,agenda_consulta.Hora AS HoraConsulta,"
                    + "agenda_consulta.Cancelado,pacientes.Nome AS "
                    + "NomePaciente FROM agenda_consulta,pacientes WHERE "
                    + "(agenda_consulta.Codigo_Paciente = pacientes.Codigo"
                    + "_Paciente) AND (agenda_consulta.Cancelado <> 'S') "
                    + "AND (agenda_consulta.Atendido <> 'S') " + " ORDER BY "
                    + "HoraConsulta";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            return this.rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
    
    public ResultSet listarHistorico(int intCodigoPaciente) {
        try {
            String strComandoSQL = "SELECT prontuario_paciente."
                    + "Codigo_Paciente AS RegistroAgenda,prontuario_paciente"
                    + ".Registro_Agenda AS RegistroAgenda,prontuario_paciente"
                    + ".Historico,prontuario_paciente.Receituario,prontuario"
                    + "_paciente.Exames,agenda_consulta.Data AS DataConsulta "
                    + "FROM prontuario_paciente,agenda_consulta WHERE "
                    + "(prontuario_paciente.Registro_Agenda = agenda_consulta"
                    + ".Registro_Agenda) AND (prontuario_paciente"
                    + ".Codigo_Paciente = " + intCodigoPaciente + ")" + 
                    " ORDER BY DataConsulta";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            return this.rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
}
