package banco_dados;

import java.sql.*;
import java.util.Date;
import model.Paciente;
import util.Conversao;
/**
 *
 * @author Danilo
 */
public class PacienteDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public PacienteDao() {
    } 
    
    public void configurarConexao(Connection conBanco) { this.conBanco = 
            conBanco; }
    
    public boolean inserirRegistro(Paciente paciente) {
        Conversao Converter = new Conversao();
        
        try {
            Date dtDataNascimento = Converter.StringToDate(paciente
                    .getDataNascimento());
            String strDataInvertida;
            if (dtDataNascimento != null) {
                strDataInvertida = Converter.DataInvertida(dtDataNascimento);
            } else {
                strDataInvertida = "null";
            }
            
            if (!strDataInvertida.equals("null")) {
                strDataInvertida = "'" + strDataInvertida + "'";
            }
            
            String strComandoSQL = "INSERT INTO pacientes(Nome,Numero_RG,"
                    + "Orgao_Emissor,Numero_CPF"
                    + ",Endereco,Numero,Complemento,Bairro,Cidade,Estado,"
                    + "Telefone,Celular,Data_Nascimento,Sexo,Tem_Convenio"
                    + ",Codigo_Convenio,Senha_Acesso) VALUES('" + paciente
                            .getNomeCompleto() + "'," + "'" + paciente
                                    .getNumeroRG() 
                    + "'," + "'" + paciente.getOrgaoEmissor() + "'," + "'" +
                    paciente.getNumeroCPF() + "'," + "'" + paciente
                            .getEndereco() + "'," + "'" + paciente.getNumero() +
                    "'," + "'" + paciente.getComplemento() + "'," 
                    + "'" + paciente.getBairro() + "'," + "'" + paciente
                            .getCidade() + "'," + "'" + paciente.getEstado() 
                    + "'," 
                    + "'" + paciente.getTelefone() + "'," + "'" + paciente
                            .getCelular() + "'," + strDataInvertida + "," + "'" 
                    + paciente.getSexo() + "'," + "'" + paciente
                            .getTemConvenio() + "'," + paciente
                                    .getCodigoConvenio() + "," + "'" 
                    + paciente.getSenhaAcesso() + "')";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            return true;
        } catch (SQLException erro) {
            System.out.println(erro.getMessage());
            return false;
        }
    }
    
    public int localizarRegistro(String strCampo,String strValor) {
        int intCodigoPaciente = 0;
        
        try {
            String strComandoSQL;
            switch (strCampo) {
                case "NOME":
                    strComandoSQL = "SELECT Codigo_Paciente FROM pacientes "
                            + "WHERE Nome LIKE '%" + strValor.toUpperCase() 
                            + "%'";
                    break;
                case "RG":
                    strComandoSQL = "SELECT Codigo_Paciente FROM pacientes "
                            + "WHERE Numero_RG = '" + strValor + "'";
                    break;
                default:
                    strComandoSQL = "SELECT Codigo_Paciente FROM pacientes "
                            + "WHERE Numero_CPF = '" + strValor + "'";
                    break;
            }
            
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            this.rsRegistros.next();
            intCodigoPaciente = this.rsRegistros.getInt("Codigo_Paciente");
        } catch (SQLException erro) {
            System.out.println(erro.getMessage());
        }
        
        return intCodigoPaciente;
    }
    
    public ResultSet lerRegistro(int intCodigoPaciente) {
        try {
            String strComandoSQL = "SELECT * FROM pacientes WHERE "
                    + "Codigo_Paciente = " + intCodigoPaciente;
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            this.rsRegistros.next();
            return this.rsRegistros;
        } catch (SQLException erro) {
            System.out.println(erro.getMessage());
            return null;
        }
    }
    
    public boolean alterarRegistro(Paciente paciente) {
        Conversao Converter = new Conversao();
        
        try {
            Date dtDataNascimento = Converter.StringToDate(paciente
                    .getDataNascimento());
            String strDataInvertida;
            if (dtDataNascimento != null) {
                strDataInvertida = Converter.DataInvertida(dtDataNascimento);
            } else {
                strDataInvertida = "null";
            }
            
            if (!strDataInvertida.equals("null")) {
                strDataInvertida = "'" + strDataInvertida + "'";
            }
            
            String strComandoSQL = "UPDATE pacientes SET Nome = '" + paciente
                    .getNomeCompleto() + "'," + "Numero_RG = '" 
                    + paciente.getNumeroRG() + "'," + "Orgao_Emissor = '" +
                    paciente.getOrgaoEmissor() + "'," + "Numero_CPF = '" 
                    + paciente.getNumeroCPF() + "'," + "Endereco = '" + 
                    paciente.getEndereco() + "'," + "Numero = '" 
                    + paciente.getNumero() + "'," + "Complemento = '" + 
                    paciente.getComplemento() + "'," + "Bairro = '" 
                    + paciente.getBairro() + "'," + "Cidade = '" + 
                    paciente.getCidade() + "'," + "Estado = '" 
                    + paciente.getEstado() + "'," + "Telefone = '" + 
                    paciente.getTelefone() + "'," + "Celular = '" 
                    + paciente.getCelular() + "'," + "Data_Nascimento = " + 
                    strDataInvertida + "," + "Sexo = '" 
                    + paciente.getSexo() + "'," + "Tem_Convenio = '" + 
                    paciente.getTemConvenio() + "'," + "Codigo_Convenio = " 
                    + paciente.getCodigoConvenio() + " WHERE Codigo_Paciente = " 
                    + paciente.getCodigoPaciente();
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            return true;
        } catch (SQLException erro) {
            System.out.println(erro.getMessage());
            return false;
        }
    }
    
    public ResultSet listarRegistros(String strNome) {
        try {
            String strComandoSQL;
            if (strNome.equals("")) {
                strComandoSQL = "SELECT * FROM pacientes ORDER BY Nome";
            } else {
                strComandoSQL = "SELECT Codigo_Paciente,Nome,Numero_RG"
                        + ",Numero_CPF FROM pacientes WHERE Nome LIKE '%" 
                        + strNome.toUpperCase() + "%' ORDER BY Nome";
            }
            
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            return this.rsRegistros;
        } catch (SQLException erro) {
            System.out.println(erro.getMessage());
            return null;
        }
    }
}

