package banco_dados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import model.AgendaConsulta;
import util.Conversao;
/**
 *
 * @author Danilo
 */
public class AgendaConsultaDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public AgendaConsultaDao() {
    }
    
    public void configurarConexao(Connection conBanco) { this.conBanco = 
            conBanco; }
    
    public boolean inserirRegistro(AgendaConsulta agenda) {
        Conversao Converter = new Conversao();
        
        try {
            Date dtDataConsulta = Converter.StringToDate(agenda
                    .getDataConsulta());
            String strDataInvertida;
            if (dtDataConsulta != null) {
                strDataInvertida = Converter.DataInvertida(dtDataConsulta);
            } else {
                strDataInvertida = "null";
            }
            
            if (!strDataInvertida.equals("null")) {
                strDataInvertida = "'" + strDataInvertida + "'";
            }
            
            String strComandoSQL = "INSERT INTO agenda_consulta(Codigo_Paciente"
                    + ",Codigo_Medico,Data,Hora,Retorno,Cancelado,"
                    + "Motivo_Cancelamento,Codigo_Usuario) VALUES(" + agenda
                            .getCodigoPaciente() + "," + agenda
                                    .getCodigoMedico() + "," + strDataInvertida 
                    + "," + "'" + agenda.getHoraConsulta() + "'," + "'" + 
                    agenda.getRetornoConsulta() + "'," + "'" + agenda
                            .getConsultaCancelada() + "'," + "'" + agenda
                                    .getMotivoCancelamento() + "'," + agenda
                                            .getCodigoUsuario() + ")";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet lerRegistro(int intRegistro) {
        try {
            String strComandoSQL = "SELECT * FROM agenda_consulta WHERE "
                    + "Registro_Agenda = " + intRegistro;
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            this.rsRegistros.next();
            return this.rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
    
    public boolean alterarRegistro(AgendaConsulta agenda) {
        try {
            String strComandoSQL = "UPDATE agenda_consulta SET Codigo_Medico = "
                    + agenda.getCodigoMedico() + "," + "Data = '" + agenda
                            .getDataConsulta() + "'," + "Hora = '" + agenda
                                    .getHoraConsulta() + "'," + 
                    "Codigo_Usuario = " + agenda.getCodigoUsuario() + 
                    " WHERE Registro_Agenda = " + agenda.getRegistro();
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public boolean cancelarRegistro(int intRegistro) {
        try {
            String strComandoSQL = "UPDATE agenda_consulta SET Cancelado = 'S' "
                    + "WHERE Registro_Agenda = " + intRegistro;
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.psComando.executeUpdate();
            return true;
        } catch (Exception erro) {
            erro.printStackTrace();
            return false;
        }
    }
    
    public ResultSet ListarAgenda(String strData) {
        try {
            String strComandoSQL = "SELECT agenda_consulta.Registro_Agenda AS "
                    + "RegistroAgenda,agenda_consulta.Codigo_Paciente AS "
                    + "CodigoPaciente,agenda_consulta.Codigo_Medico AS "
                    + "CodigoMedico,agenda_consulta.Data AS DataConsulta"
                    + ",agenda_consulta.Hora AS HoraConsulta,agenda_consulta"
                    + ".Retorno,agenda_consulta.Cancelado,agenda_consulta"
                    + ".Codigo_Usuario AS CodigoUsuario,pacientes.Nome AS "
                    + "NomePaciente,pacientes.Numero_RG AS RGPaciente,pacientes"
                    + ".Numero_CPF AS CPFPaciente,medicos.Nome_Medico AS "
                    + "Medico FROM agenda_consulta,pacientes,medicos "
                    + "WHERE (agenda_consulta.Codigo_Paciente = pacientes"
                    + ".Codigo_Paciente) AND (agenda_consulta.Codigo_Medico = "
                    + "medicos.Codigo_Medico) AND (agenda_consulta.Cancelado "
                    + "<> 'S') AND (agenda_consulta.Data = '" + strData + "')" 
                    + " ORDER BY DataConsulta,HoraConsulta";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            return this.rsRegistros;
        } catch (Exception erro) {
            erro.printStackTrace();
            return null;
        }
    }
}
