/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banco_dados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author Danilo
 */
public class EstadoDao {
    private Connection conBanco;
    private PreparedStatement psComando;
    private ResultSet rsRegistros;
    
    public EstadoDao(){
        
    }
    
    public void configurarConexao(Connection conBanco) {this.conBanco = conBanco;}
    
    public ResultSet lerRegistro(String strUF) {
        try {
            String strComandoSQL = "SELECT * FROM estados WHERE UF = '" + strUF + "'";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            this.rsRegistros.next();
            return this.rsRegistros;
        } 
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public ResultSet listarRegistros() {
        try {
            String strComandoSQL = "SELECT * FROM estados ORDER BY Estado";
            this.psComando = this.conBanco.prepareStatement(strComandoSQL);
            this.rsRegistros = this.psComando.executeQuery();
            return this.rsRegistros;
        } 
        catch (Exception ex){
            ex.printStackTrace();
            return null;
        }
    }
}
