/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Danilo
 */
public class UsuarioVinculo {
    private int codigoUsuarioVinculo;
    private int codigo_funcionario;
    private int codigoUsuario;
    
    public UsuarioVinculo()
    {
        codigoUsuarioVinculo = 0;
        codigo_funcionario = 0;
        codigoUsuario = 0;
    }
    
    public UsuarioVinculo(int codigo_funcionario,
        int codigoUsuario)
    {
        this.codigo_funcionario = codigo_funcionario;
        this.codigoUsuario = codigoUsuario;
    }
        
        public void setCodigoUsuarioVinculo(int codigoUsuarioVinculo) {this.codigoUsuarioVinculo = codigoUsuarioVinculo;}
        public int getCodigoUsuarioVinculo() {return codigoUsuarioVinculo;}
        
        public void setCodigoFuncionario(int codigo_funcionario) {this.codigo_funcionario = codigo_funcionario;}
        public int getCodigoFuncionario() {return codigo_funcionario;}
        
        public void setCodigoUsuario(int codigoUsuario) {this.codigoUsuario = codigoUsuario;}
        public int getCodigoUsuario() {return codigoUsuario;}
}
