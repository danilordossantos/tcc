package model;

/**
 *
 * @author Danilo
 */
public class Paciente extends Pessoa{
    private int codigo_paciente;
    private String tem_convenio;
    private int codigo_convenio;
    private String senha_acesso;
    
    public Paciente() {
        super("","","","","","","","","","","","","","","","");
        this.tem_convenio = "N";
        this.codigo_convenio = 0;
        this.senha_acesso = "";
    }
    
    public Paciente(String nome, String numero_rg, String orgao_emissor, 
            String numero_cpf, String endereco, String numero
            , String complemento, String bairro, String cidade, String estado, 
            String telefone, String celular, String sexo
            , String dia_nascimento, String mes_nascimento, 
            String ano_nascimento, String tem_convenio, int codigo_convenio) {
        super(nome, numero_rg, orgao_emissor, numero_cpf, endereco, 
                numero, complemento, bairro, cidade, estado, telefone, celular, 
                sexo, dia_nascimento, mes_nascimento, ano_nascimento);
        this.tem_convenio = tem_convenio;
        this.codigo_convenio = codigo_convenio;
    }
    
    public int getCodigoPaciente() { return this.codigo_paciente; }
    public void setCodigoPaciente(int codigo_paciente) { this.codigo_paciente = 
            codigo_paciente; }
    
    public String getTemConvenio() { return this.tem_convenio; }
    public void setTemConvenio(String tem_convenio) { this.tem_convenio = 
            tem_convenio; }
    
    public int getCodigoConvenio() { return this.codigo_convenio; }
    public void setCodigoConvenio(int codigo_convenio) { this.codigo_convenio = 
            codigo_convenio; }
    
    public String getSenhaAcesso() { return this.senha_acesso; }
    public void setSenhaAcesso(String senha_acesso) { this.senha_acesso = 
            senha_acesso.toUpperCase(); }
}
