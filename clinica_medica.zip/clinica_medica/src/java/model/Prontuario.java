package model;

/**
 *
 * @author Danilo
 */
public class Prontuario {
    private int registro_agenda;
    private String historico;
    private String receituario;
    private String exames;
    private int codigo_paciente;
    
    public Prontuario() {
        this.registro_agenda = 0;
        this.historico = "";
        this.receituario = "";
        this.exames = "";
        this.codigo_paciente = 0;
    }
    
    public Prontuario(int registro_agenda, String historico, String receituario,
            String exames, int codigo_paciente) {
        this.registro_agenda = registro_agenda;
        this.historico = historico;
        this.receituario = receituario;
        this.exames = exames;
        this.codigo_paciente = codigo_paciente;
    }
    
    public int getRegistroAgenda() { return this.registro_agenda; }
    public void setRegistroAgenda(int registro_agenda) { this.registro_agenda = 
            registro_agenda; }
    
    public String getHistorico() { return this.historico; }
    public void setHistorico(String historico) { this.historico = historico; }
    
    public String getReceituario() { return this.receituario; }
    public void setReceituario(String receituario) { this.receituario = 
            receituario; }
    
    public String getExames() { return this.exames; }
    public void setExames(String exames) { this.exames = exames; }
    
    public int getCodigoPaciente() { return this.codigo_paciente; }
    public void setCodigoPaciente(int codigo_paciente) { this.codigo_paciente = 
            codigo_paciente; }
}
