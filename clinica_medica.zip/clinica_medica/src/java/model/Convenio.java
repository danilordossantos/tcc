/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Danilo
 */
public class Convenio {
    private String nomeConvenio,
            CNPJ,
            telefone;
    private int codigoConvenio;
    
    public Convenio()
    {
        this.nomeConvenio = "";
        this.CNPJ = "";
        this.telefone = "";
        this.codigoConvenio = 0;
    }
    
    public Convenio(String nomeConvenio,
            String CNPJ,
            String telefone)
    {
        this.nomeConvenio = nomeConvenio.toUpperCase();
        this.CNPJ = CNPJ;
        this.telefone = telefone;
    }
    
    public void setNomeConvenio(String nomeConvenio) {this.nomeConvenio = 
            nomeConvenio.toUpperCase();}
    public String getNomeConvenio() {return nomeConvenio;}
    
    public void setCNPJ(String CNPJ) {this.CNPJ = CNPJ;}
    public String getCNPJ() {return CNPJ;}
    
    public void setTelefone(String telefone) {this.telefone = telefone;}
    public String getTelefone() {return telefone;}
    
    public void setCodigoConvenio(int codigoConvenio) {this.codigoConvenio = 
            codigoConvenio;}
    public int getCodigoConvenio() {return codigoConvenio;}
}
