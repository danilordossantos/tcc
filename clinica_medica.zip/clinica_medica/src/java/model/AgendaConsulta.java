/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Danilo
 */
public class AgendaConsulta {
    private int registro;
    private int codigo_paciente;
    private int codigo_medico;
    private String data_consulta;
    private String hora_consulta;
    private String retorno_consulta;
    private String consulta_cancelada;
    private String motivo_cancelamento;
    private int codigoUsuario;
    
    public AgendaConsulta() {
        this.registro = 0;
        this.codigo_paciente = 0;
        this.codigo_medico = 0;
        this.data_consulta = "";
        this.hora_consulta = "";
        this.retorno_consulta = "";
        this.consulta_cancelada = "";
        this.motivo_cancelamento = "";
        this.codigoUsuario = 0;
    }
    
    public AgendaConsulta(int codigo_paciente, int codigo_medico, 
            String data_consulta, String hora_consulta, 
            String retorno_consulta, String consulta_cancelada, 
            String motivo_cancelamento, int codigoUsuario) {
        this.codigo_paciente = codigo_paciente;
        this.codigo_medico = codigo_medico;
        this.data_consulta = data_consulta;
        this.hora_consulta = hora_consulta;
        this.retorno_consulta = retorno_consulta;
        this.consulta_cancelada = consulta_cancelada;
        this.motivo_cancelamento = motivo_cancelamento;
        this.codigoUsuario = codigoUsuario;
    }
    
    public int getRegistro() { return this.registro; }
    
    public void setRegistro(int registro) { this.registro = registro; }
    
    public int getCodigoPaciente() { return this.codigo_paciente; }
    
    public void setCodigoPaciente(int codigo_paciente) { this.codigo_paciente 
            = codigo_paciente; }
    
    public int getCodigoMedico() { return this.codigo_medico; }
    
    public void setCodigoMedico(int codigo_medico) { this.codigo_medico 
            = codigo_medico; } 
    
    public String getDataConsulta() { return this.data_consulta; }
    
    public void setDataConsulta(String data_consulta) { this.data_consulta 
            = data_consulta; }
    
    public String getHoraConsulta() { return this.hora_consulta; }
    
    public void setHoraConsulta(String hora_consulta) { this.hora_consulta 
            = hora_consulta; }
    
    public String getRetornoConsulta() { return this.retorno_consulta; }
    
    public void setRetornoConsulta(String retorno_consulta) { 
        this.retorno_consulta = retorno_consulta; }
    
    public String getConsultaCancelada() { return this.consulta_cancelada; }
    
    public void setConsultaCancelada(String consulta_cancelada) { 
        this.consulta_cancelada = consulta_cancelada; }
    
    public String getMotivoCancelamento() { return this.motivo_cancelamento; }
    
    public void setMotivoCancelamento(String motivo_cancelamento) { 
        this.motivo_cancelamento = motivo_cancelamento; }
    
    public int getCodigoUsuario() { return this.codigoUsuario; }
    
    public void setCodigoUsuario(int codigoUsuario) { this.codigoUsuario = 
            codigoUsuario; }
}
